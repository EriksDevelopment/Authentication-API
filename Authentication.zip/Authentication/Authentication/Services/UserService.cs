using JwtAuthDemo.Models;
using System.Collections.Generic;
using System.Linq;
using BCrypt.Net;

namespace JwtAuthDemo.Services
{
    public class UserService
    {
        private static List<User> users = new List<User>();

        public bool Register(string username, string password)
        {
            if (users.Any(u => u.Username == username)) return false;

            string passwordHash = BCrypt.Net.BCrypt.HashPassword(password);
            users.Add(new User { Username = username, PasswordHash = passwordHash });
            return true;
        }

        public bool ValidateUser(string username, string password)
        {
            var user = users.SingleOrDefault(u => u.Username == username);
            return user != null && BCrypt.Net.BCrypt.Verify(password, user.PasswordHash);
        }
    }
}